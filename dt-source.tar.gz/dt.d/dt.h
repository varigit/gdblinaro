/****************************************************************************
 *									    *
 *			  COPYRIGHT (c) 1990 - 2010			    *
 *			   This Software Provided			    *
 *				     By					    *
 *			  Robin's Nest Software Inc.			    *
 *									    *
 * Permission to use, copy, modify, distribute and sell this software and   *
 * its documentation for any purpose and without fee is hereby granted,	    *
 * provided that the above copyright notice appear in all copies and that   *
 * both that copyright notice and this permissikn notice appear in the	    *
 * supporting documentation, and that the name of the author not be used    *
 * in advertising or publicity pertaining to distribution of the software   *
 * without specific, written prior permission.				    *
 *									    *
 * THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, 	    *
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN	    *
 * NO EVENT SHALL HE BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL   *
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR    *
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS  *
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF   *
 * THIS SOFTWARE.							    *
 *									    *
 ****************************************************************************/
/*
 * Modification History:
 *
 * October 29th, 2007 by Robin T. Miller.
 *	Modify Windows times() definition to return a clock ticks value,
 * which is consistent with what's returned by standard Unix times() API.
 *
 * January 19th, 2005 by Nagendra Vadlakunta
 * 	Added AIO and IA64 support for Windows.
 *
 * June 22nd, 2004 by Robin Miller.
 *      Added support for triggers on corruption.
 *
 * September 27th, 2003 by Robin Miller.
 *      Added support for AIX.
 *
 * March 14th, 2003 by Robin Miller.
 *	Add declarations for slice and prefix variables.
 *
 * November 14th, 2002 by Robin Miller.
 *	Add support for 32-bit HP-UX compilation.
 *
 * February 23rd, 2002 by Robin Miller.
 *	Make porting changes for HP-UX IA64.
 *
 * February 1st, 2002 by Robin Miller.
 *	Make porting changes necessary for Solaris 8.
 *
 * August 31st, 2001 by Robin Miller.
 *	Increase size of di_capacity from 32 to 64 bits in preparation
 * for larger capacity volumes, esp. logical volumes on array controllers.
 *
 * January 24th, 2001 by Robin Miller.
 *	For Windows/NT, use /dev/[n]rmt instead of "tapeN" for tape
 * device names, since this is the name used when tapes are mounted
 * using the Cygnus toolkit.
 *
 * January 14th, 2001 by Robin Miller.
 *	Added support for multiple volumes option.
 *
 * January 11th, 2001 by Robin Miller.
 *	Modify conditionals so Windows tape devices are /dev/rmtN
 * and /dev/nrmtN (norewind)  which the latest Cygnus README states.
 *
 * December 30th, 2000 by Robin Miller.
 *	Make changes to build using MKS/NuTCracker product.
 *
 * April 17th, 2000 by Robin Miller.
 *	Added device path failure flag, to force re-open of tapes
 * on Wave4 clusters which forces alternate paths or servers to be
 * located by CAM or DRD.
 *
 * January 22nd, 2000 by Robin Miller.
 *	Added support for Cygwin tape devices for Windows/NT.
 *
 * August 6th, 1999 by Robin Miller.
 *      Better parameterizing of "long long" printf formatting.
 *
 * July 29, 1999 by Robin Miller.
 *	Merge in changes made to compile on FreeBSD.
 *
 * July 22nd, 1999 by Robin Miller.
 *	Added support for IOT (DJ's) test pattern.
 * 
 * May 27, 1999 by Robin Miller.
 *	Added support for micro-second delays.
 *
 * April 8, 1999 by Robin Miller.
 *	Merge in Jeff Detjen's changes for table()/sysinfo timing.
 *
 * December 21, 1998 by Robin Miller.
 *	For DUNIX, changes to handle tape resets.
 *
 * April 29, 1998 by Robin Miller.
 *	Add support for an alternate device directory, e.g. "/devices/",
 * as a prefix to physical device names.  Just checking for "/dev...",
 * described below, is too general and sure to get me into trouble.
 *
 * April 25, 1998 by Robin Miller.
 *	Change device prefix to account for "/dev" or "/devices" (steel),
 * since this knowledge is used to determine if a device should exist
 * (to avoid creating files in the /dev directory), as well as whether
 * the PID is appended during multiple process testing.
 *
 * February 28, 1996 by Robin Miller.
 *	Added support for copying and verifying device/files.
 *
 * December 19, 1995 by Robin Miller
 *      Conditionalize for Linux Operating System.
 *
 * September 23, 1994 by Robin Miller.
 *      Make changes necessary to build on QNX 4.21 release.
 *
 * September 5, 1992 by Robin Miller.
 *	Initial port to QNX 4.1 Operating System.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <time.h> 				/* CLK_TCK defined here */
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

#if defined(WIN32)
//#  define TIMER_METHOD 1
#  if defined(TIMER_METHOD)
     /* For CreateWaitableTimer() & SetWaitableTimer() */
#    define _WIN32_WINNT 0x0500
#  endif /* defined(TIMER_METHOD) */
#  include<windows.h>
#  include<io.h>
#  include<direct.h>
#  include<process.h>
#else /* !defined(WIN32) */
#  include <unistd.h>
#  include <termios.h>
#  include <sys/times.h>
#  if !defined(NOSYSLOG)
#    define SYSLOG 1
#    include <syslog.h>
#  endif /* defined(NOSYSLOG) */
#  if defined(__CYGWIN__)
#    include <sys/time.h>
#  endif /* defined(__CYGWIN__) */
#  endif /* defined(WIN32) */
#if defined(__QNXNTO__)
#  include <unix.h>
#endif

/*
 * Definition to control timestamps (may affect performance).
 */
#define TIMESTAMP       1

#define RETRY_DELAY	5

/*
 * These are found in <tzfile.h> on Tru64 UNIX and Solaris.
 */
#define SECS_PER_MIN	60
#define MINS_PER_HOUR	60
#define HOURS_PER_DAY	24
#define SECS_PER_HOUR	(SECS_PER_MIN * MINS_PER_HOUR)
#define SECS_PER_DAY	(SECS_PER_HOUR * HOURS_PER_DAY)

#define mSECS_PER_SEC	1000
#define uSECS_PER_SEC	1000000

#if defined(DEC)
#  include <sys/table.h>
#endif /* defined(DEC) */

#if defined(EEI)
#  include <sys/mtio.h>
#endif /* defined(EEI) */

#if defined(MUNSA)
#  include <assert.h>
#  include <sys/dlm.h>
dlm_lock_mode_t    munsa_lock;
#endif /* defined(MUNSA) */

#if !defined(HZ)
#  if defined(sun) || defined(__WIN32__) || defined(SCO) || defined(HP_UX)
#    include <sys/param.h>
#  endif /* defined(sun) */
#  if defined(CLK_TCK) && !defined(HZ)
#    define HZ		CLK_TCK
#  else
#    if !defined(HZ)
#      define HZ		256
#    endif /* !defined(HZ) */
#    if !defined(CLK_TCK)
#      define CLK_TCK	HZ
#    endif /* !defined(CLK_TCK) */
#  endif /* defined(CLK_TCK) */
#endif /* !defined(HZ) */

#if defined(DEC)
#  define LOG_DIAG_INFO	1
#endif /* defined(DEC) */

#if defined(__alpha) || defined(__LP64__)
#  define MACHINE_64BITS
#endif /* defined(__alpha) || defined(__LP64__) */

#define DIR_PREFIX	"d"
#if defined(WIN32)
#  define DIRSEP	'\\'
#else /* !defined(WIN32) */
#  define DIRSEP	'/'
typedef int		 HANDLE;
#  define OFF_T 	 off_t
#endif /* !defined(WIN32) */

#if defined(WIN32)
# if 0
struct timeval {
    long    tv_sec;         /* seconds */
    long    tv_usec;        /* and microseconds */
};
#  endif /* 0 */
extern int gettimeofday(struct timeval *tp, void *tzp);
#  define getuid()	 1
#  define sleep(a)	Sleep(a*1000)
#  define usleep(a)	Sleep(a/1000)
#  define alarm(sec) 	winAlarm(sec)
#  define times(a)	(time(0) * hz)
#  define getpid	_getpid
#  define unlink	_unlink
#  define stat		_stat
#  define strdup	_strdup
#  define fileno	_fileno
#  define isatty	_isatty
#  define mkdir		_mkdir
#  define popen		_popen
#  define pclose	_pclose
#  define strncasecmp   _strnicmp
#  define SIGALRM	14

  struct AlrmArgs {
      DWORD timeout;
      HANDLE event;
      HANDLE handle;
  };

  struct tms {                
     clock_t  tms_utime;     
     clock_t  tms_stime;     
     clock_t  tms_cutime;    
     clock_t  tms_cstime;    
  };

  typedef int pid_t;
  typedef unsigned int speed_t;
  typedef int	ssize_t; 
  typedef LONGLONG OFF_T;

# define SYSLOG		1
# define LOG_ERR	EVENTLOG_ERROR_TYPE
# define LOG_INFO	EVENTLOG_INFORMATION_TYPE

  extern void syslog(int priority, char *format, ...);

# if !defined(INVALID_SET_FILE_POINTER)
#   define INVALID_SET_FILE_POINTER -1
# endif

#endif /* defined(WIN32) */

#if !defined(MAXHOSTNAMELEN)
#   define MAXHOSTNAMELEN 256
#endif

/*
 * Block Processing Macros:
 */
#if !defined(howmany)
#  define howmany(x, y)   (((x)+((y)-1))/(y))
#endif /* !defined(howmany) */
#if !defined(roundup)
#  define roundup(x, y)   ((((x)+((y)-1))/(y))*(y))
#endif /* !defined(roundup) */
#if !defined(rounddown)
#  define rounddown(x,y)  (((x)/(y))*(y))
#endif /* !defined(rounddown) */

/*
 * Macros for fast min/max.
 */
#if !defined(MIN)
#  define MIN(a,b) (((a)<(b))?(a):(b))
#endif /* !defined(MIN) */
#if !defined(MAX)
#  define MAX(a,b) (((a)>(b))?(a):(b))
#endif /* if !defined(MAX) */

/*
 * Macro to calculate the starting block of where error occured.
 *    ( 'x' = byte count or file offset, 'y' = block size )
 */
#define WhichBlock(x,y)		((x)/(y))

/*
 * Default Disk Block Shift Size:
 *
 * This value is used to convert a byte count into a block number.
 * This default is making a presumption the disk block size is 512.
 * This shift value is used in conjuntion with capacity to calculate
 * large random I/O offsets over 1 terabyte.
 * Note: This can go away after we add our own random # generator
 * which is not limited to values returned by standard library API's.
 */
#define DEFAULT_BLOCK_SHIFT	8	/* log2(512)-1 shift value. */

#if defined(__CYGWIN__) && defined(__STRICT_ANSI__)
int     _EXFUN(fileno, (FILE *));
#endif

/*
 * Large value for 32 or 64 bit systems.
 *
 * Note: Most systems are now defined quad_t or u_quad_t for
 *	 "long long" values, but I've chosen to avoid conflicts
 *	 by defining my own typedef's (for now :-).  The other
 *	 reason for my own definitions is to avoid the following:
 *
 *	 typedef struct  _quad { int val[2]; } quad;
 *
 *	 used by some systems that don't support "long long" :-)
 *
 */
#if defined(MACHINE_64BITS)

#if defined(_WIN64)

#define QuadIsLong
typedef ULONG64 		 large_t;
typedef LONG64 	        	 slarge_t;
typedef volatile large_t         v_large;
typedef volatile slarge_t 	 v_slarge; 
#define LUF	 "%I64u"
#define LDF	 "%I64d"
#define LXF	 "%I64x"
#define FUF	 LUF 
#define FXF	 LXF 

#else /* !defined(_WIN64)*/

#define QuadIsLong
typedef unsigned long		large_t;
typedef signed long		slarge_t;
typedef volatile large_t	v_large;
typedef volatile slarge_t	v_slarge;
#define LUF	"%lu"
#define LDF	"%ld"
#define LXF	"%#lx"
#define FUF	LUF
#define FXF	LXF

#endif /* defined(_WIN64) */

#elif defined(__GNUC__) && defined(_BSD_SOURCE) || defined(SCO) || defined(__QNXNTO__) || defined(SOLARIS) || defined(HP_UX) || defined(AIX) || defined(_NT_SOURCE) 

#define QuadIsLongLong
typedef unsigned long long int	large_t;
typedef signed long long int	slarge_t;
typedef volatile large_t	v_large;
typedef volatile slarge_t	v_slarge;
#if defined(__QNXNTO__) || defined(SOLARIS) || defined(HP_UX) || defined(AIX) || defined(_NT_SOURCE)
#  define LUF   "%llu"
#  define LDF   "%lld"
#  define LXF   "%#llx"
#elif defined(SCO)
#  define LUF	"%Lu"
#  define LDF	"%Ld"
#  define LXF	"%#Lx"
#else /* !defined(SCO) && !defined(__QNXNTO__) && !defined(HP_UX) && !defined(AIX) */
#  define LUF	"%qu"
#  define LDF	"%qd"
#  define LXF	"%#qx"
#endif /* defined(__QNXNTO__) */

#if defined(_FILE_OFFSET_BITS) && (_FILE_OFFSET_BITS == 64)
#  define FUF	LUF
#  define FXF	LXF
#else /* !defined(_FILE_OFFSET_BITS) || (_FILE_OFFSET_BITS != 64) */
#  define FUF	"%lu"
#  define FXF	"%#lx"
#endif /* defined(_FILE_OFFSET_BITS) && (_FILE_OFFSET_BITS == 64) */

#elif defined(__NUTC__)

#define QuadIsLongLong

typedef u_quad_t		large_t;
typedef quad_t			slarge_t;
typedef volatile large_t	v_large;
typedef volatile slarge_t	v_slarge;
#define LUF	"%qu"
#define LDF	"%qd"
#define LXF	"%#qx"
#define FUF	"%lu"
#define FXF	"%#lx"

#elif defined(WIN32)

#define QuadIsLongLong

typedef ULONGLONG		 large_t;
typedef LONGLONG 		 slarge_t;
typedef volatile large_t         v_large;
typedef volatile slarge_t 	 v_slarge; 
#define LUF	 "%I64u"
#define LDF	 "%I64d"
#define LXF	 "%I64x"
#define FUF	 LUF 
#define FXF	 LXF 

#else /* !defined(MACHINE_64BITS) && !defined(__GNUC__) */

#define QuadIsDouble
typedef double			large_t;
typedef double			slarge_t;
typedef volatile large_t	v_large;
typedef volatile slarge_t	v_slarge;

#define LUF	"%.0f"
#define LDF	"%.0f"
#define LXF	"%.0f"	/* ??? no hex ??? */
#define FUF	"%lu"
#define FXF	"%#lx"

#endif /* defined(MACHINE_64BITS) */

/*
 * Create some shorthands for volatile storage classes:
 */
typedef	volatile char	v_char;
typedef	volatile short	v_short;
typedef	volatile int	v_int;
typedef volatile long	v_long;
#if !defined(DEC)
/* These are defined in sys/types.h on DEC Alpha systems. */
typedef	volatile unsigned char	vu_char;
typedef	volatile unsigned short	vu_short;
typedef	volatile unsigned int	vu_int;
typedef volatile unsigned long	vu_long;
#endif /* !defined(__alpha) */

#define SUCCESS		0			/* Success status code. */
#define FAILURE		-1			/* Failure status code. */
#define WARNING		1			/* Warning status code.	*/
#define TRUE		1			/* Boolean TRUE value.	*/
#define FALSE		0			/* Boolean FALSE value.	*/
#define UNINITIALIZED	255			/* Uninitialized flag.	*/
#define NO_LBA		0xFFFFFFFFFFFFFFFFULL	/* No LBA vlaue.	*/

#define BLOCK_SIZE		512		/* Bytes in block.	*/
#define KBYTE_SIZE		1024		/* Kilobytes value.	*/
#define MBYTE_SIZE		1048576L	/* Megabytes value.	*/
#define GBYTE_SIZE		1073741824L	/* Gigabytes value.	*/

#define IOT_SEED	0x01010101		/* Seed for IOT pattern	*/

/*
 * These buffer sizes are mainly for allocating stack space
 * for pre-formatting strings to display.  Different sizes
 * to prevent wasting stack space (my preference).
 */
#define SMALL_BUFFER_SIZE       32              /* Small buffer size.   */
#define MEDIUM_BUFFER_SIZE      64              /* Medium buffer size.  */
#define LARGE_BUFFER_SIZE       128             /* Large buffer size.   */
/*
 * Note: This should be the largest file path allowed for any Host OS.
 *	 On Linux, "errno = 36 - File name too long" occurs at 4096.
 *	 This will usually be used for short term stack allocated space.
 */
#define PATH_BUFFER_SIZE	8192		/* Max path size.	*/
/*
 * Note: Now that long file paths are created, this string buffer must
 *	 be large enough for message text *and* the long file names!
 */
#define STRING_BUFFER_SIZE (PATH_BUFFER_SIZE+256)/* String buffer size.	*/

#if defined(WIN32)
#  define MAX_PROCS       MAXIMUM_WAIT_OBJECTS	/* Maximum processes.	*/
#  define MAX_SLICES      MAXIMUM_WAIT_OBJECTS	/* Maximum processes.	*/
#  define HANDLE_TERMINATE if (terminating_flag) ExitThread(ERROR_SUCCESS);
#  define TERM_WAIT_TIMEOUT	10		/* Wait timeout (secs).	*/
#  define TERM_WAIT_RETRIES	6		/* Time to retry wait.	*/
#  define TERM_WAIT_ARETRIES	1		/* Abnormal wait retry.	*/
#else /* !defined(WIN32) */
#  define MAX_PROCS	256			/* Maximum processes.	*/
#  define MAX_SLICES	256			/* Maximum slices.	*/
#  define HANDLE_TERMINATE
#endif /* defined(WIN32) */
#define USE_PATTERN_BUFFER			/* Use pattern buffer.	*/

#undef INFINITY
#if defined(MACHINE_64BITS)
#  define MAX_SEEK	0x8000000000000000UL /* Maximum lseek() value.	*/
#  define MAX_LONG	0x7fffffffffffffffL  /* Maximum positive long.	*/
#  define MAX_ULONG	0xffffffffffffffffUL /* Maximum u_long value.	*/
#  define INFINITY	MAX_ULONG	/* Maximum possible long value.	*/
#  define DEFAULT_PATTERN 0x39c39c39U	/* Default data pattern.	*/
#  define ASCII_PATTERN	  0x41424344U	/* Default ASCII data pattern.	*/
#  define TBYTE_SIZE	1099511627776L		/* Terabytes value.	*/
#else /* !defined(MACHINE_64BITS */
#  define MAX_LONG	0x7fffffffL	/* Maximum positive long value.	*/
#  define MAX_ULONG	0xffffffffUL	/* Maximum unsigned long value.	*/
#  if defined(_FILE_OFFSET_BITS) && (_FILE_OFFSET_BITS == 64)
#    define MAX_SEEK	0x8000000000000000ULL /* Maximum lseek() value. */
#  else /* if !defined(_FILE_OFFSET_BITS) || (_FILE_OFFSET_BITS != 64) */
#    define MAX_SEEK	0x80000000UL	/* Maximum lseek() value.	*/
#  endif /* defined(_FILE_OFFSET_BITS) && (_FILE_OFFSET_BITS == 64) */
#  if defined(QuadIsLongLong)
#    if defined(__NUTC__)
#      define MAX_ULONG_LONG 0xffffffffffffffffui64
#      define INFINITY	 MAX_ULONG_LONG	/* Maximum possible large value */
#      define TBYTE_SIZE 1099511627776i64       /* Terabytes value.	*/
#    elif defined(WIN32)
#      define MAX_ULONG_LONG  ~((ULONGLONG) 0)
#      define INFINITY  MAX_ULONG_LONG
#      define TBYTE_SIZE (large_t)1095511627776
#    else 
#      define MAX_ULONG_LONG 0xffffffffffffffffULL
#      define INFINITY	 MAX_ULONG_LONG	/* Maximum possible large value */
#      define TBYTE_SIZE 1099511627776LL	/* Terabytes value.	*/
#    endif /* defined(__NUTC__) */
#  else /* assume QuadIsDouble */
#    if defined(__WIN32__)
       /* HUGE_VAL seems to be defined as 0.0, which is NFG! */
#      define INFINITY  (double)0x10000000000000L /* Max large value???	*/
#    else
#      define INFINITY	HUGE_VAL	/* Maximum possible large value */
#    endif
#    define TBYTE_SIZE	((double)GBYTE_SIZE*1024) /* Terabytes value.	*/
#  endif /* defined(QuadIsLongLong) */
#  define DEFAULT_PATTERN 0x39c39c39UL	/* Default data pattern.	*/
#  define ASCII_PATTERN	  0x41424344UL	/* Default ASCII data pattern.	*/
#endif /* defined(MACHINE_64BITS) */

/*
 * Shorthand macros for string compare functions:
 */
#define EQ(x,y)		(strcmp(x,y)==0)	/* String EQ compare.	*/
#define EQL(x,y,n)	(strncmp(x,y,n)==0)	/* Compare w/length.	*/

#define NE(x,y)		(strcmp(x,y)!=0)	/* String NE compare.	*/
#define NEL(x,y,n)	(strncmp(x,y,n)!=0)	/* Compare w/length.	*/

#define EQS(x,y)	(strstr(x,y) != NULL)	/* Sub-string equal.	*/
#define EQSC(x,y)	(strcasestr(x,y) != NULL) /* Case insensitive.	*/

#define NES(x,y)	(strstr(x,y) == NULL)	/* Sub-string not equal	*/
#define NESC(x,y)	(strcasestr(x,y) == NULL) /* Case insensitive.	*/

/*
 * Define some known device names (for automatic device recognition).
 */
#if defined(WIN32)
#  define DEV_PREFIX	"\\\\.\\"	/* Native Windows device dir.	*/
#  define DEV_LEN	4		/* That's for "\\.\" prefix.	*/
#  define ADEV_PREFIX	"//./"		/* Windows hidden device dir.	*/
#  define ADEV_LEN	4		/* Length of device name prefix.*/
#else /* !defined(WIN32) */
#  define DEV_PREFIX	"/dev/"		/* Physical device name prefix.	*/
#  define DEV_LEN	5		/* Length of device name prefix.*/
#endif /* defined(WIN32) */
/*
 * Alternate Device Directory:
 */
#if defined(WIN32)
#  define ADEV_PREFIX	"//./"		/* Windows hidden device dir.	*/
#  define ADEV_LEN	4		/* Length of device name prefix.*/
#elif defined(_NT_SOURCE)
#  define ADEV_PREFIX	"//./"		/* Windows hidden device dir.	*/
#  define ADEV_LEN	4		/* Length of device name prefix.*/
#  define NDEV_PREFIX	"\\\\.\\"	/* Native Windows device dir.	*/
#  define NDEV_LEN	4		/* That's for "\\.\" prefix.	*/
#else /* !defined(_NT_SOURCE) */
#  define ADEV_PREFIX	"/devices/"	/* Physical device name prefix.	*/
#  define ADEV_LEN	9		/* Length of device name prefix.*/
#  define NDEV_PREFIX	"/dev/"		/* Native device prefix (dup).	*/
#  define NDEV_LEN	5		/* Native device prefix length.	*/
#endif /* defined(_NT_SOURCE) */

#define CONSOLE_NAME	"console"	/* The console device name.	*/
#define CONSOLE_LEN	7		/* Length of console name.	*/

#if defined(_QNX_SOURCE)
#  define CDROM_NAME	"cd"		/* Start of CD-ROM device name.	*/
#  define RCDROM_NAME	"cd"		/* Start of raw CD-ROM names.	*/
#elif defined(sun) || defined(__linux__)
/* Note: Don't know about Sun systems. */
#  define CDROM_NAME	"cd"		/* Start of CD-ROM device name.	*/
#  define RCDROM_NAME	"scd"		/* Start of raw CD-ROM names.	*/
/* NOTE: Linux (RedHat V6.0) currently has no raw CD-ROM names! */
#elif defined(SCO)
#  define CDROM_NAME	"cdrom"		/* Start of CD-ROM device name.	*/
#  define RCDROM_NAME	"rcdrom"	/* Start of raw CD-ROM names.	*/
#elif defined(_NT_SOURCE)
#  define CDROM_NAME	"Cdrom"		/* Start of CD-ROM device name.	*/
#  define RCDROM_NAME	"cdrom"		/* Allow both upper/lowercase.	*/
#else
#  define CDROM_NAME	"rz"		/* Start of CD-ROM device name.	*/
#  define RCDROM_NAME	"rrz"		/* Start of raw CD-ROM names.	*/
#endif /* !defined(_QNX_SOURCE) */

#if defined(AIX)
#  define DISK_NAME	"hd"		/* Start of disk device names.	*/
#  define RDISK_NAME	"rhd"		/* Start of raw disk names.	*/
#elif defined(_QNX_SOURCE)
#  define DISK_NAME	"hd"		/* Start of disk device names.	*/
#  define RDISK_NAME	"hd"		/* Start of raw disk names.	*/
#elif defined(sun) || defined(__linux__)
#  define DISK_NAME	"sd"		/* Start of disk device names.	*/
#  define RDISK_NAME	"rsd"		/* Start of raw disk names.	*/
/* NOTE: Linux (RedHat V6.0) currently has no raw disk names! */
#elif defined(SCO) || defined(HP_UX)
#  define DISK_NAME	"dsk"		/* Start of disk device names.	*/
#  define RDISK_NAME	"rdsk"		/* Start of raw disk names.	*/
#elif defined(_NT_SOURCE) || defined(WIN32)
#  define DISK_NAME	"PhysicalDrive"	/* Start of disk device names.	*/
#  define RDISK_NAME	"physicaldrive"	/* Allow both upper/lowercase.	*/
#else
#  define DISK_NAME	"rz"		/* Start of disk device names.	*/
#  define RDISK_NAME	"rrz"		/* Start of raw disk names.	*/
#endif /* !defined(_QNX_SOURCE) */

#if defined(_QNX_SOURCE)
#  define TTY_NAME	"ser"		/* Start of terminal names.	*/
#elif defined(__NUTC__)
#  define TTY_NAME	"com"		/* Start of terminal names.	*/
#else /* !defined(_QNX_SOURCE) */
#  define TTY_NAME	"tty"		/* Start of terminal names.	*/
#endif /* defined(_QNX_SOURCE) */
#define TTY_LEN		3		/* Length of terminal name.	*/

#if defined(_QNX_SOURCE)
#  define TAPE_NAME	"tpr"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"tp"		/* No-rewind tape device name.	*/
#elif defined(sun)
#  define TAPE_NAME	"rst"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"nrst"		/* No-rewind tape device name.	*/
#elif defined(__linux__)
#  define TAPE_NAME	"st"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"nst"		/* No-rewind tape device name.	*/
#elif defined(SCO)
#  define TAPE_NAME	"ctape"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"ntape"		/* No-rewind tape device name.	*/
#elif defined(_NT_SOURCE)
#  define TAPE_NAME	"rmt"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"nrmt"		/* No-rewind tape device name.	*/
#else
#  define TAPE_NAME	"rmt"		/* Start of tape device names.	*/
#  define NTAPE_NAME	"nrmt"		/* No-rewind tape device name.	*/
#endif /* !defined(_QNX_SOURCE) */

//#define DEF_LOG_BUFSIZE	2048	/* Large enough for all stats.	*/
#define DEF_LOG_BUFSIZE	PATH_BUFFER_SIZE /* Large enough for all stats.	*/

#if defined(BUFSIZ) && (BUFSIZ > DEF_LOG_BUFSIZE)
#  define LOG_BUFSIZE	BUFSIZ		/* The log file buffer size.	*/
#else /* !defined(BUFSIZ) */
#  define LOG_BUFSIZE	DEF_LOG_BUFSIZE	/* The log file buffer size.	*/
#endif /* defined(BUFSIZ) */

#define ANY_RADIX	0		/* Any radix string conversion.	*/
#define DEC_RADIX	10		/* Base for decimal conversion.	*/
#define HEX_RADIX	16		/* Base for hex str conversion.	*/

/*
 * Define some Architecture dependent types:
 */
#if defined(__alpha) || defined(__LP64__) || defined(_WIN64)
#if defined(_WIN64)
typedef ULONG64			ptr_t;
#else
typedef unsigned long		ptr_t;
#endif
typedef int			int32;
typedef unsigned int		u_int32;
typedef unsigned int		bool;
typedef volatile unsigned int	v_bool;

#else /* !defined(__alpha) */

typedef unsigned int		ptr_t;
#if !defined(AIX)
#if !defined(OSFMK)
typedef int			int32;
#endif /* !defined(OSFMK) */
typedef unsigned int		u_int32;
#endif /* !defined(AIX) */
typedef unsigned char		bool;
typedef volatile unsigned char	v_bool;

#endif /* defined(__alpha) */

/*
 * Some systems don't have these definitions:
 */
#if defined(__MSDOS__) || defined(WIN32)

typedef	unsigned char		u_char;
typedef	unsigned short		u_short;
typedef	unsigned int		u_int;
typedef unsigned long		u_long;
typedef char *			caddr_t;
typedef unsigned long		daddr_t;

#endif /* defined(__MSDOS__) || defined(WIN32) */

#if defined(ultrix) || defined(sun)

#if !defined(SOLARIS) && !defined(AIX)
typedef int			ssize_t;
#endif /* !defined(SOLARIS) && !defined(AIX) */

#endif /* defined(ultrix) */

/*
 * The buffer pad bytes are allocated at the end of all data buffers,
 * initialized with the inverted data pattern, and then checked after
 * each read operation to ensure extra bytes did not get transferred
 * at the end of buffer.  This test is necessary, since quite often
 * we've seen data corruption (extra bytes) due to improper flushing
 * of DMA FIFO's, or other coding errors in our SCSI/CAM sub-system.
 */
#define PADBUFR_SIZE	sizeof(u_int32)	/* The data buffer pad size.	*/
					/* MUST match pattern length!!!	*/

/*
 * The buffer rotate size are used to force unaligned buffer access
 * by rotating the starting buffer address through the sizeof(ptr).
 * This feature has been very useful in forcing drivers through special
 * code to handle unaligned addresses & buffers crossing page boundaries.
 */
#define ROTATE_SIZE	sizeof(char *)	/* Forces through all ptr bytes	*/

/*
 * 'dt' specific exit status codes:
 */
#define END_OF_FILE	254			/* End of file code.	*/
#define FATAL_ERROR	255			/* Fatal error code.	*/

#define get_lbn(bp)	( ((u_int32)bp[3] << 24) | ((u_int32)bp[2] << 16) | \
			  ((u_int32)bp[1] << 8) | (u_int32)bp[0])

/*
 * Structure for Baud Rate Lookup.
 */
struct tty_baud_rate {
	u_int32	usr_speed;		/* User entered speed value.	*/
	speed_t	tty_speed;		/* Parameter for tty driver.	*/
};

typedef enum opt {OFF, ON, OPT_NONE} opt_t;
typedef enum flow {FLOW_NONE, CTS_RTS, XON_XOFF} flow_t;
typedef enum stats {COPY_STATS, READ_STATS, RAW_STATS, WRITE_STATS, TOTAL_STATS, VERIFY_STATS} stats_t;
typedef enum dispose {DELETE_FILE, KEEP_FILE, KEEP_ON_ERROR} dispose_t;
typedef enum file_type {INPUT_FILE, OUTPUT_FILE} file_type_t;
typedef enum test_mode {READ_MODE, WRITE_MODE} test_mode_t;
typedef enum onerrors {ABORT, CONTINUE} onerrors_t;
typedef enum iodir {FORWARD, REVERSE} iodir_t;
typedef enum iomode {COPY_MODE, TEST_MODE, VERIFY_MODE} iomode_t;
typedef enum iotype {SEQUENTIAL_IO, RANDOM_IO} iotype_t;

/*
 * History Information:
 */
typedef struct history {
    test_mode_t	hist_test_mode;		/* The I/O mode.       		*/
    u_long	hist_file_number;	/* The file number.		*/
    u_long	hist_record_number;	/* The record number.		*/
    OFF_T	hist_file_offset;	/* The file offset.		*/
    size_t	hist_request_size;	/* Size of the request.		*/
    ssize_t	hist_transfer_size;	/* Size of the transfer.	*/
    u_char	*hist_request_data;	/* First 'N' bytes of data.	*/
    struct timeval hist_timer_info;	/* Timer info in sec/usecs.	*/
} history_t;

#define DEFAULT_HISTORY_DATA_SIZE	32

/*
 * The operation type is used with no-progress option to report operation.
 */
typedef enum optype {
    NONE_OP, OPEN_OP, CLOSE_OP, READ_OP, WRITE_OP, IOCTL_OP, FSYNC_OP, MSYNC_OP, AIOWAIT_OP, NUM_OPS
} optype_t;
typedef struct optiming {
    optype_t	opt_optype;		/* The operation type.      */
    bool	opt_timing_flag;	/* The timing control flag. */
    char	*opt_name;		/* The operation name.      */
} optiming_t;
extern optiming_t optiming_table[];

typedef enum statslevel {STATS_BRIEF, STATS_FULL, STATS_NONE} statslevel_t;
typedef enum stats_value {ST_BYTES, ST_BLOCKS, ST_FILES, ST_RECORDS} stats_value_t;
typedef enum trigger_type {
    TRIGGER_NONE, TRIGGER_BR, TRIGGER_BDR, TRIGGER_SEEK, TRIGGER_CMD, TRIGGER_INVALID=-1
} trigger_type_t;
typedef enum trigger_action {
    TRIGACT_CONTINUE = 0, TRIGACT_TERMINATE = 1, TRIGACT_SLEEP = 2, TRIGACT_ABORT = 3
} trigger_action_t;

typedef enum logLevel {
	logLevelCrit = -1,
	logLevelError,
	logLevelInfo,
	logLevelWarn,
	logLevelDiag,
	logLevelQdiag,
	logLevelLog,
	logLevelSpecial,
	logLevelTrace
} logLevel_t;

/*
 * Flags to control print behaviour:
 */
#define PRT_NOFLUSH	0x01
#define PRT_NOIDENT	0x02
#define PRT_NOLEVEL	0x04

/*
 * Declare the external test functions:
 *
 * TODO:  Tape test functions...
 */
#define NOFUNC		(int (*)()) 0	/* No test function exists yet. */

#if defined(WIN32)
#  define NoFd          INVALID_HANDLE_VALUE
#else /* !defined(WIN32) */
#  define NoFd		-1		/* No file descriptor open.	*/
#endif /* defined(WIN32) */

extern int nofunc();			/* Stub return (no test func).	*/
extern struct dtfuncs generic_funcs;	/* Generic test functions.	*/
#if defined(AIO)
extern struct dtfuncs aio_funcs;	/* POSIX AIO test functions.	*/
#endif /* defined(AIO) */
#if defined(MMAP)
extern struct dtfuncs mmap_funcs;	/* Memory map test functions.	*/
#endif /* defined(MMAP) */
extern struct dtfuncs tty_funcs;	/* Terminal test functions.	*/
#if defined(FIFO)
extern struct dtfuncs fifo_funcs;	/* Named pipes test functions.	*/
#endif /* defined(FIFO) */

/*
 * Define various device types:
 */
enum devtype {DT_AUDIO, DT_BLOCK, DT_CHARACTER, DT_COMM, DT_DISK,
	      DT_GRAPHICS, DT_MEMORY, DT_MMAP, DT_MOUSE, DT_NETWORK,
	      DT_FIFO, DT_PIPE, DT_PRINTER, DT_PROCESSOR, DT_REGULAR,
	      DT_SOCKET, DT_SPECIAL, DT_STREAMS, DT_TAPE, DT_TERMINAL,
	      DT_DIRECTORY, DT_UNKNOWN };
struct dtype {
	char	*dt_type;
	enum	devtype dt_dtype;
};

extern struct dtype *input_dtype;
extern struct dtype *output_dtype;

/*
 * Define file control flags:
 */
#define DCF_ACTIVE	1		/* File test is active.		*/

/************************************************************************
 * NOTE: Eventually, all device specific data must be moved to this	*
 *	 data structure, but that will be done in stages since there's	*
 *	 a fair amount of work involved.  Can you say re-write? :-)	*
 ************************************************************************/

/*
 * Define device type information:
 */
typedef struct dinfo {
	HANDLE	di_fd;			/* The file descriptor.		*/
	int	di_flags;		/* The file control flags.	*/
	int	di_oflags;		/* The last file open flags.	*/
	char	*di_bname;		/* The base file name.		*/
	char	*di_dname;		/* The /dev device name.	*/
	char	*di_device;		/* The real device name.	*/
	/*
	 * Test Information:
	 */
	enum test_mode di_mode;		/* The current test mode.	*/
	enum file_type di_ftype;	/* The file access type.	*/
	struct dtype *di_dtype;		/* The device type information.	*/
	struct dtfuncs *di_funcs;	/* The test functions to use.	*/
	/*
	 * Statistics and State Information:
	 */
	bool	di_closing;		/* The device is being closed.	*/
	bool	di_flushing;		/* The file is being flushed.	*/
	bool	di_fsync_flag;		/* The file sync (fsync) flag.	*/
	bool	di_existing_file;	/* The file already exists.	*/
	u_int32	di_dsize;		/* The device block size.	*/
	u_int32	di_rshift;		/* The random shift value.	*/
        u_int   di_qdepth;              /* The device queue depth.      */
	large_t	di_capacity;		/* The device capacity (blocks)	*/
	v_bool	di_end_of_file;		/* End of file was detected.	*/
	v_bool	di_end_of_logical;	/* End of logical tape detected	*/
	v_bool	di_end_of_media;	/* End of media was detected.	*/
	v_bool	di_beginning_of_file;	/* Beginning of file/media flag	*/
	v_bool	di_no_space_left;	/* The "no space left" flag.	*/
	bool	di_eof_processing;	/* End of file proessing.	*/
	bool	di_eom_processing;	/* End of media processing.	*/
	bool	di_random_io;		/* Random I/O selected flag.	*/
	bool	di_random_access;	/* Random access device flag.	*/
	v_large	di_dbytes_read;		/* Number of data bytes read.	*/
	v_large	di_dbytes_written;	/* Number of data bytes written.*/
	v_large	di_fbytes_read;		/* Number of file bytes read.	*/
	v_large	di_fbytes_written;	/* Number of file bytes written.*/
	v_large	di_vbytes_read;		/* Number of volume bytes read.	*/
	v_large	di_vbytes_written;	/* Number of volume bytes wrote.*/
	/*
	 * Information to Handle "File System Full":
	 */
	large_t	di_last_dbytes_written;	/* The last data bytes written.	*/
	large_t	di_last_fbytes_written;	/* The last file bytes written.	*/
	large_t	di_last_vbytes_written;	/* The last volume bytes wrote.	*/
	large_t	di_discarded_write_data;/* Discarded write data bytes.	*/
	/*
	 * Multiple Directory Data:
	 */
	char	*di_dir;		/* The base directory path.	*/
	char	*di_dirpath;		/* The directory path.		*/
	char	*di_subdir;		/* The sub-directory path.	*/
	bool	di_dir_created;		/* We created directory flag.	*/
	u_int	di_dir_number;		/* The directory number.	*/
	u_int	di_subdir_number;	/* The subdirectory number.	*/
	u_int	di_subdir_depth;	/* The subdirectory depth.	*/
	u_int	di_last_dir_number;	/* The last directory number.	*/
	u_int	di_last_subdir_number;	/* The subdirectory number.	*/
	u_int	di_last_subdir_depth;	/* The subdirectory depth.	*/
	u_int	di_max_dir_number;	/* The maximum directory.	*/
	u_int	di_max_subdir_number;	/* The maximum subdirectory.	*/
	u_int	di_max_subdir_depth;	/* The maximum subdir depth.	*/
	/*
	 * Multiple Files Data:
	 */
	u_int	di_file_limit;		/* The maximum files per pass.	*/
	u_int	di_file_number;		/* The current file number.	*/
	u_long	di_last_files_read;	/* The last files read.		*/
	u_long	di_last_files_written;	/* The last files written.	*/
	u_long	di_max_files_read;	/* The maximum files read.	*/
	u_long	di_max_files_written;	/* The maximum files written.	*/
	large_t di_max_data;		/* Max data limit (all files).	*/
	u_int	di_max_files;		/* Max file limit (all dirs).	*/
	v_large	di_maxdata_read;	/* Max data read (all files).	*/
	v_large	di_maxdata_written;	/* Max data written (all files)	*/
	/*
	 * Per Pass Information:
	 */
	vu_long	di_files_read;		/* Number of files read.	*/
	vu_long	di_files_written;	/* Number of files written.	*/
        u_long  di_full_reads;          /* The # of full records read.  */
        u_long  di_full_writes;         /* The # of full records written*/
        u_long  di_partial_reads;       /* Partial # of records read.   */
        u_long  di_partial_writes;      /* Partial # of records written */
	vu_long	di_records_read;	/* Number of records read.	*/
	vu_long	di_records_written;	/* Number of records written.	*/
	vu_long	di_volume_records;	/* Number of volume records.	*/
	vu_long di_read_errors;		/* Number of read errors.	*/
	vu_long di_write_errors;	/* Number of write errors.	*/
	large_t	di_data_limit;		/* The data limit (in bytes).	*/
	large_t	di_volume_bytes;	/* Accumulated volume bytes.	*/
	/*
	 * Monitoring Information:
	 */
	volatile time_t	di_initiated_time; /* Time the I/O was initiated.*/
	volatile time_t	di_last_alarm_time;/* The last alarm time (secs).*/
	volatile time_t	di_last_keepalive;/* The last keepalive (secs).	*/
	/*
	 * Extended Error Information (EEI) State:
	 */
	bool	di_proc_eei;		/* Processing EEI data flag.	*/
#if defined(EEI)
#define EEI_RESET	1		/* Delay after resets.		*/
#define EEI_SLEEP	3		/* Time between retries.	*/
#define EEI_RETRIES	100		/* Number of EEI retries.	*/
#define EEI_OPEN_RETRIES 3		/* Number of open retries.	*/
	bool	di_devpath_failure;	/* Path failure condition.	*/
	bool	di_reset_condition;	/* Reset condition detected.	*/
	struct mtget *di_mt;		/* The tape error information.	*/
	int	di_eei_retries;		/* The number of EEI retries.	*/
	int	di_eei_sleep;		/* Time to sleep between retry.	*/
#endif /* defined(EEI) */
        /*
         * Information for Error Reporting / Trigger:
         */
        OFF_T	di_offset;		/* Device/file offset at error.	*/
        large_t di_lba;                 /* Logical/relative block addr. */
        u_int32 di_position;            /* Position into failing block. */
	v_int	di_errno;		/* The last errno encountered.	*/
        enum trigger_type di_trigger;   /* The trigger type (if any).   */
	optype_t di_optype;		/* The current operation type.	*/
	/*
	 * Retry Parameters:
	 */
	v_bool	di_retrying;		/* The recovery retrying flag.	*/
	u_char	*di_saved_pattern_ptr;	/* Saved pattern buf pointer.	*/
	/*
	 * History Information:
	 */
	int	di_history_size;	/* Size of the history array.	*/
	int	di_history_entries;	/* Number of history entries.	*/
	int	di_history_index;	/* Index to next history entry.	*/
	int	di_history_data_size;	/* Request data size to save.	*/
	history_t *di_history;		/* Array of history entries.	*/
	/*
	 * Data Pattern Related Information:
	 */
	u_char	*di_pattern_buffer;	/* The data pattern buffer.	*/
	char	*di_pattern_string;	/* The pattern string.		*/
	int	di_pattern_size;	/* The data pattern size.	*/
	char	*di_prefix_string;	/* The prefix string (if any).	*/
	int	di_prefix_size;		/* The prefix string size.	*/
	int	di_pattern_index;	/* The pass pattern index.	*/
} dinfo_t;

/*
 * Define test function dispatch structure:
 *
 * [ NOTE:  These functions are not all used at this time.  The intent
 *   is to cleanup the code later by grouping functions appropriately. ]
 */
struct dtfuncs {
						/* Open device or file.	   */
	int	(*tf_open)(struct dinfo	*dip, int oflags);
						/* Close device or file.   */
	int	(*tf_close)(struct dinfo *dip);
						/* Special initilization.  */
	int	(*tf_initialize)(struct dinfo *dip);
						/* Start test processing.  */
	int	(*tf_start_test)(struct dinfo *dip);
						/* End of test processing. */
	int	(*tf_end_test)(struct dinfo *dip);
						/* Read file data.	   */
	int	(*tf_read_file)(struct dinfo *dip);
						/* Processes read data.	   */
	int	(*tf_read_data)(struct dinfo *dip);
						/* Cancel read requests.   */
	int	(*tf_cancel_reads)(struct dinfo *dip);
						/* Write file data.	   */
	int	(*tf_write_file)(struct dinfo *dip);
						/* Processes write data.   */
	int	(*tf_write_data)(struct dinfo *dip);
						/* Cancel write requests.  */
	int	(*tf_cancel_writes)(struct dinfo *dip);
						/* Flush data to media.	   */
	int	(*tf_flush_data)(struct dinfo *dip);
						/* Verify data read.	   */
	int	(*tf_verify_data)(	struct dinfo	*dip,
					u_char		*buffer,
					size_t		count,
					u_int32		pattern,
					u_int32		*lba );
						/* Reopen device or file.  */
	int	(*tf_reopen_file)(struct dinfo *dip, int oflags);
						/* Test startup handling.  */
	int	(*tf_startup)(struct dinfo *dip);
						/* Test cleanup handling.  */
	int	(*tf_cleanup)(struct dinfo *dip);
						/* Validate test options.  */
	int	(*tf_validate_opts)(struct dinfo *dip);
};

/*
 * Macros to Improve Performance:
 *
 * Note: Others can be added after debug is conditionalized.
 */
#define INLINE_FUNCS 1

#if defined(INLINE_FUNCS)

#define make_lba(dip, pos)	\
	((pos == (OFF_T) 0) ? (u_int32) 0 : (pos / lbdata_size))

#define make_offset(dip, lba)	((OFF_T)(lba * lbdata_size))

#define make_lbdata(dip, pos)	\
	((pos == (OFF_T) 0) ? (u_int32) 0 : (pos / lbdata_size))

#define make_position(dip, lba)	((OFF_T)(lba * lbdata_size))

#if defined(_BSD)
#  define get_position(dip) (seek_position (dip, (OFF_T) 0, L_INCR))
#else /* !defined(_BSD) */
#  define get_position(dip) (seek_position (dip, (OFF_T) 0, SEEK_CUR))
#endif /* defined(_BSD) */

#endif /* defined(INLINE_FUNCS) */

#if defined(MUNSA)

extern bool		munsa_flag;		/* Enable MUNSA features flag. */
extern dlm_lock_mode_t	munsa_lock_type;	/* Default munsa lock type.    */
extern dlm_lock_mode_t	input_munsa_lock_type;	/* Lock for input file.        */
extern dlm_lock_mode_t	output_munsa_lock_type;	/* Lock for output file.       */
extern char		*resnam;
extern int		resnlen, i;
extern dlm_lkid_t	lkid;
extern dlm_nsp_t	nsp;
extern dlm_valb_t	vb;

#endif /* defined(MUNSA) */

extern FILE *efp, *ofp;
extern struct dinfo *active_dinfo, *input_dinfo, *output_dinfo;

#if defined(AIX)
#  undef hz
#endif
extern clock_t hz;
extern bool tty_saved;
extern int exit_status;
extern unsigned parity_code, data_bits_code;
extern speed_t baud_rate;
extern u_int32 pattern;
extern u_int32 data_patterns[];
extern int npatterns;
extern enum opt softcar_opt;
extern enum flow flow_type;
extern enum iodir io_dir;
extern enum iomode io_mode;
extern enum iotype io_type;
extern enum dispose dispose_mode;
extern enum devtype device_type;
extern enum onerrors oncerr_action;
extern enum statslevel stats_level;
extern enum trigger_type trigger;
extern char *parity_str, *flow_str, *speed_str, *trigger_cmd, *trigger_args;

/* XXX */
extern char	*fprefix_string;
extern int	fprefix_size;
/* XXX */
extern bool history_dump, history_timing;
extern int history_data_size, history_size;
extern bool user_pattern, unique_pattern;
extern char *pattern_string, *prefix_string;
extern int align_offset, rotate_offset;
extern bool ade_flag, aio_flag, bypass_flag;
extern bool compare_flag, core_dump, cerrors_flag;
extern bool debug_flag, Debug_flag;
extern bool eDebugFlag, fDebugFlag, pDebugFlag, rDebugFlag, tDebugFlag;
#if defined(EEI)
extern bool eei_flag, eei_resets;
#endif /* defined(EEI) */
extern bool dio_flag, dump_flag, flush_flag, forked_flag;
extern bool fsync_flag, fsalign_flag, multiple_dirs, multiple_files;
extern bool header_flag, keep_existing, hazard_flag, loop_on_error;
extern bool lbdata_flag, noprog_flag, user_lbdata, user_lbsize;
extern bool unique_file, user_incr, user_min, user_max, user_ralign;
extern bool user_position, incr_pattern, iot_pattern;
extern bool logappend_flag, logdiag_flag, logpid_flag, unique_log, syslog_flag;
extern bool loopback, micro_flag, mmap_flag, modem_flag, stdin_flag, stdout_flag;
extern bool max_capacity, media_changed, multi_flag, variable_flag, volumes_flag;
extern volatile bool terminating_flag;
extern bool timestamp_flag, ttyport_flag;
extern bool verbose_flag, verify_flag, verify_only;
extern bool rotate_flag, pad_check, spad_check, sighup_flag, sparse_flag;
extern bool prefill_flag, pstats_flag, raw_flag, stats_flag, trigargs_flag;
extern bool retryDC_flag, retryIO_flag;

extern char *cmdname;
extern u_char *base_buffer, *data_buffer, *verify_buffer;
extern char *cmd_line, *msg_buffer;
extern char *log_file, *log_buffer, *log_bufptr;
extern char *dirpath, *dirprefix, *input_file, *output_file, *pattern_file;
extern u_char *mmap_buffer, *mmap_bufptr;
extern u_char *pattern_buffer, *pattern_bufptr, *pattern_bufend;
extern size_t patbuf_size;
extern int pattern_size, prefix_size, page_size;
extern size_t block_size, data_size, lbdata_size;
extern u_int32 device_size, iot_pass, iot_seed, lbdata_addr;

extern int open_flags, wopen_flags;
extern size_t dump_limit, incr_count, min_size, max_size;
extern u_int dir_limit, file_limit, max_files, subdir_depth, subdir_limit;
extern u_long pass_count, pass_limit;
extern u_long seek_count, skip_count;
extern large_t record_limit, total_bytes;
extern large_t total_records, total_records_read, total_records_written;
extern large_t total_bytes_read, total_bytes_written;
extern large_t total_files, total_files_read, total_files_written;
extern u_long error_limit;
extern vu_long total_errors;
extern u_long total_partial, total_partial_reads, total_partial_writes;
extern u_long warning_errors;
extern u_int cdelay_count, edelay_count, rdelay_count, sdelay_count;
extern u_int tdelay_count, wdelay_count, retry_delay;
extern u_int random_seed;
extern v_int multi_volume;
extern int volume_limit;
extern vu_long volume_records;

/*
 * Volatile Storage:
 */
extern bool eof_status;
extern v_bool end_of_file;
extern u_long random_align;
extern vu_long error_count;
extern u_long partial_records, records_processed;
extern large_t data_limit, max_data, rdata_limit, user_capacity;

extern bool tty_minflag;
extern u_short tty_timeout, tty_minimum;

extern OFF_T end_position, file_position, last_position, step_offset;

extern clock_t start_time, end_time, pass_time;
extern struct tms stimes, ptimes, etimes;

#if defined(DEC)
extern bool table_flag;
extern struct tbl_sysinfo s_table, p_table, e_table;
#endif /* defined(DEC) */

extern time_t alarmtime, noprogtime, noprogttime, runtime, elapsed_time;
extern time_t program_start, program_end, error_time, keepalive_time;
extern bool TimerActive, TimerExpired;
extern bool StdinIsAtty, StdoutIsAtty, StderrIsAtty;
extern bool user_keepalive, user_pkeepalive, user_tkeepalive;
extern char *keepalive, *pkeepalive, *tkeepalive;
extern char *keepalive0, *keepalive1;
extern char *user_runtime;

extern bool child_flag;   
extern pid_t child_pid, process_id;
extern int cur_proc, num_procs, num_slices, slice_num;

#if defined(AIO)
extern int aio_bufs;
#endif /* defined(AIO) */

#if defined(_BSD)
extern union wait child_status;
#else /* !defined(_BSD) */
extern int child_status;
#endif /* defined(_BSD) */

#if defined(HP_UX)
extern u_int qdepth;
#endif /* defined(HP_UX) */

#if defined(SOLARIS)
/* This is for enabling Direct I/O on VxFS! */
#  define VX_IOCTL        (('V' << 24) | ('X' << 16) | ('F' << 8))
#  define VX_SETCACHE     (VX_IOCTL | 1)   /* set cache advice */
#  define VX_DIRECT       0x00004          /* perform direct (un-buffered) i/o */
#endif /* defined(SOLARIS) */

/*
 * Function Prototypes: (No ANSI compiler? too bad... buy one! :-)
 */

/* dt.c */
extern void log_header(void);
extern int match(char *s);
extern void report_error(char *error_info, int record_flag);
extern void report_record(
			struct dinfo	*dip,
			u_long		files,
			u_long		records,
			large_t		lba,
                        OFF_T           pos,
			enum test_mode	mode,
			void		*buffer,
			size_t		bytes );
extern void keepalive_alarm(int sig);
extern void terminate(int code);
extern int nofunc(struct dinfo *dip);
extern int HandleMultiVolume(struct dinfo *dip);
extern int RequestFirstVolume(struct dinfo *dip, int oflags);
extern int RequestMultiVolume(struct dinfo *dip, bool reopen, int open_flags);

#if defined(MUNSA)
extern void dlm_error(dlm_lkid_t *lk, dlm_status_t l_stat);
#endif /* defined(MUNSA) */

/* dtgen.c */
extern char *make_file_name(struct dinfo *dip);
extern int open_file(struct dinfo *dip, int mode);
extern int close_file(struct dinfo *dip);
extern int reopen_file(struct dinfo *dip, int mode);
extern int initialize(struct dinfo *dip);
extern int init_file(struct dinfo *dip);
extern int flush_file(struct dinfo *dip);
extern int read_file(struct dinfo *dip);
extern int write_file(struct dinfo *dip);
extern int validate_opts(struct dinfo *dip);
#if defined(SOLARIS)
extern int SolarisDIO(struct dinfo *dip, char *file);
#endif /* defined(SOLARIS) */

/* dtinfo.c */
extern struct dtype *setup_device_type(char *str);
extern struct dinfo *setup_device_info(char *dname, struct dtype *dtp);
extern void system_device_info(struct dinfo *dip);
extern int setup_directory_info(struct dinfo *dip, char *dir);
extern void init_vars(struct dinfo *dip);

/* dtread.c */
extern int read_data(struct dinfo *dip);
extern int check_read(struct dinfo *dip, ssize_t count, size_t size);
extern int read_eof(struct dinfo *dip);
extern int read_eom(struct dinfo *dip);
extern ssize_t read_record(	struct dinfo	*dip,
				u_char		*buffer,
				size_t		bsize,
				size_t		dsize,
				int		*status );
extern int verify_record(	struct dinfo	*dip,
				u_char		*buffer,
				size_t		bsize );
extern int FindCapacity(struct dinfo *dip);

/* dtwrite.c */
extern int write_data(struct dinfo *dip);
extern int check_write(struct dinfo *dip, ssize_t count, size_t size);
extern int copy_record(		struct dinfo	*dip,
				u_char		*buffer,
				size_t		bsize );
extern ssize_t write_record(	struct dinfo	*dip,
				u_char		*buffer,
				size_t		bsize,
				size_t		dsize,
				int		*status );
extern int write_verify(	struct dinfo	*dip,
				u_char		*buffer,
				size_t		bsize,
				size_t		dsize,
				OFF_T		pos );

/* dtstats.c */
extern void gather_stats(struct dinfo *dip);
extern void gather_totals(struct dinfo *dip);
extern void init_stats(struct dinfo *dip);
extern void report_pass(struct dinfo *dip, enum stats stats_type);
extern void report_stats(struct dinfo *dip, enum stats stats_type);

/* dttty.c */
extern int tty_open(struct dinfo *dip, int mode);
extern int tty_close(struct dinfo *dip);
extern int tty_reopen(struct dinfo *dip, int mode);
extern int tty_flush_data(struct dinfo *dip);
extern int drain_tty(int fd);
extern int flush_tty(int fd);
extern int save_tty(int fd);
extern int restore_tty(int fd);
extern int setup_tty(int fd, int flushing);
extern int setup_baud_rate(u_int32 baud);
extern int SetBlockingMode (int fd);
#if defined(_OSF_SOURCE) || defined(ultrix)
extern unsigned int GetModemSignals(int fd);
extern int HangupModem(int fd);
extern int ShowModemSignals(int fd);
extern int WaitForCarrier(int fd);
#endif /* defined(_OSF_SOURCE) || defined(ultrix) */

/* dtutil.c */
extern int create_directory(struct dinfo *dip, char *dir);
extern int remove_current_directory(struct dinfo *dip);
extern int remove_directory(struct dinfo *dip, char *dir);
extern int delete_file(struct dinfo *dip, char *file);
extern int delete_files(struct dinfo *dip);
extern int delete_subdir_files(struct dinfo *dip, char *spath);
extern bool file_exists(struct dinfo *dip, char *file);
extern int truncate_file(struct dinfo *dip, OFF_T offset);
extern void mySleep(unsigned int sleep_time);
extern void SleepSecs(unsigned int sleep_time);
extern void dump_buffer(	char		*name,
				u_char		*base,
				u_char		*ptr,
				size_t		dump_size,
				size_t		bufr_size,
				bool		expected);
extern void fill_buffer(	u_char		*buffer,
				size_t		byte_count,
				u_int32		pattern);
extern void init_buffer(	u_char		*buffer,
				size_t		count,
				u_int32		pattern );
#if _BIG_ENDIAN_
extern void init_swapped (	u_char		*buffer,
		                size_t		count,
		                u_int32		pattern );
#endif /* _BIG_ENDIAN_ */

extern u_int32 init_lbdata(	u_char		*buffer,
				size_t		count,
				u_int32		lba,
				u_int32		lbsize );
#if defined(TIMESTAMP)
extern void init_timestamp (    u_char		*buffer,
                        	size_t		count,
                        	u_int32		dsize );
extern void display_timestamp(u_char *buffer);
#endif /* defined(TIMESTAMP) */

#if !defined(INLINE_FUNCS)
extern u_int32 make_lba(	struct dinfo	*dip,
				OFF_T		pos );
extern OFF_T make_offset(	struct dinfo	*dip,
				u_int32		lba);
extern u_int32 make_lbdata(	struct dinfo	*dip,
				OFF_T		pos );
#endif /* !defined(INLINE_FUNCS) */
extern u_int32 winit_lbdata(	struct dinfo	*dip,
				OFF_T		pos,
				u_char		*buffer,
				size_t		count,
				u_int32		lba,
				u_int32		lbsize );
extern u_int32 init_iotdata(	size_t		bcount,
				u_int32		lba,
				u_int32		lbsize );
extern void init_padbytes(	u_char		*buffer,
				size_t		offset,
				u_int32		pattern);
extern char *bformat_time (char *bp, clock_t time);
extern void print_time(FILE *fp, clock_t time);
extern void format_time(clock_t time);
#if defined(DEC)
extern void format_ltime (long time, int tps);
#endif /* defined(DEC) */
extern int verify_buffers(	struct dinfo	*dip,
				u_char		*dbuffer,
				u_char		*vbuffer,
				size_t		count );
extern int verify_lbdata(	struct dinfo	*dip,
				u_char		*dbuffer,
				u_char		*vbuffer,
				size_t		count,
				u_int32		*lba );
extern int verify_data(		struct dinfo	*dip,
				u_char		*buffer,
				size_t		byte_count,
				u_int32		pattern,
				u_int32		*lba );
extern int verify_padbytes(	struct dinfo	*dip,
				u_char		*buffer,
				size_t		count,
				u_int32		pattern,
				size_t		offset );
extern void process_pfile(HANDLE *fd, char *file, int mode);
extern void copy_pattern(u_int32 pattern, u_char *buffer);
extern void setup_pattern(u_char *buffer, size_t size);
extern OFF_T seek_file(HANDLE fd, u_long records, OFF_T size, int whence);
extern OFF_T seek_position(struct dinfo *dip, OFF_T size, int whence);
#if !defined(INLINE_FUNCS)
extern OFF_T get_position(struct dinfo *dip);
#endif /* !defined(INLINE_FUNCS) */
extern u_int32 get_lba(struct dinfo *dip);
extern OFF_T incr_position(struct dinfo *dip, OFF_T offset);
extern OFF_T set_position(struct dinfo *dip, OFF_T offset);
#if !defined(INLINE_FUNCS)
extern OFF_T make_position(struct dinfo *dip, u_int32 lba);
#endif /* !defined(INLINE_FUNCS) */
extern void show_position(struct dinfo *dip, OFF_T pos);
extern u_long get_random(void);
extern large_t get_random64(void);
extern size_t get_variable(struct dinfo *dip);
extern void set_rseed(u_int seed);
extern OFF_T do_random(struct dinfo *dip, bool doseek, size_t xfer_size);
extern int skip_records(struct dinfo *dip, u_long records, u_char *buffer, size_t size);
extern void *myalloc(size_t size, int offset);
extern void *Malloc(size_t size);
extern void *Realloc(void *bp, size_t size);
extern u_long CvtStrtoValue(char *nstr, char **eptr, int base);
extern large_t CvtStrtoLarge(char *nstr, char **eptr, int base);
extern time_t CvtTimetoValue(char *nstr, char **eptr);
#if defined(ultrix)
extern clock_t times(struct tms *tmsp);
#endif /* defined(ultrix) */
#if defined(ultrix)
extern void *valloc(size_t size);
#endif /* defined(ultrix) */
extern void Ctime(time_t timer);
extern char *fmtmsg_prefix(char *bp);
extern void LogMsg(FILE *fp, enum logLevel level, int flags, char *fmtstr, ...);
extern u_long RecordError(struct dinfo *dip);
extern u_long RecordWarning(u_long record);
#if defined(WIN32)
extern LPVOID error_msg(void);
extern OFF_T SetFilePtr(HANDLE hf, OFF_T distance, DWORD MoveMethod);
#endif /* defined(WIN32) */
#if 1 /* Why this Red? */
extern void Fprintf(char *format, ...);
extern void Fprint(char *format, ...);
extern void Lprintf(char *format, ...);
extern void Printf(char *format, ...);
extern void Print(char *format, ...);
extern void Perror(char *format, ...);
#if defined(WIN32)
#endif /* defined(WIN32) */
extern void wPerror(char *format, ...);
#endif
#if !defined(_QNX_SOURCE) && !defined(__linux__) && !defined(FreeBSD) && !defined(__osf__) && !defined(__NUTC__) && !defined(__CYGWIN__)
extern void bzero(char *buffer, size_t length);
#endif /* !defined(_QNX_SOURCE) && !defined(__linux__) && !defined(FreeBSD) && !defined(__osf__) && !defined(__NUTC__) */
extern void Lflush(void);
extern int Sprintf(char *bufptr, char *msg, ...);
extern int Fputs(char *str, FILE *stream);
extern bool isFsFullOk(struct dinfo *dip, char *op);
extern int is_Eof(struct dinfo *dip, size_t count, int *status);
extern void set_Eof(struct dinfo *dip);
extern void ReportCompareError(	struct dinfo	*dip,
				size_t		byte_count,
				u_int		byte_position,
				u_int		expected_data,
				u_int		data_found );
extern void ReportDeviceInfo(	struct dinfo	*dip,
				size_t		byte_count,
				u_int		byte_position,
				bool		eio_error );
extern void ReportLbdataError(	struct dinfo	*dip,
			        u_int32		lba,
				u_int32		byte_count,
				u_int32		byte_position,
				u_int32		expected_data,
				u_int32		data_found );

extern int IS_HexString(char *s);
extern int FmtKeepAlive(struct dinfo *dip, char *keepalivefmt, char *buffer);
extern int FmtPrefix(struct dinfo *dip, char *prefix, int psize);
extern int StrCopy(void *to_buffer, void *from_buffer, size_t length);
extern large_t stoh(u_char *bp, size_t size);
extern void htos(u_char *bp, large_t value, size_t size);
extern void LogDiagMsg(char *msg);
extern enum trigger_type check_trigger_type(char *str);
extern int ExecuteTrigger(struct dinfo *dip, ...);
extern large_t GetStatsValue(struct dinfo *dip, stats_value_t stv, bool pass_stats, int *secs);
extern void *malloc_palign(size_t size);
extern void free_palign(void *pa_addr);
extern void dump_history_data(struct dinfo *dip);
extern void save_history_data(	struct dinfo	*dip,
				u_long		file_number,
				u_long		record_number,
				test_mode_t	test_mode,
				OFF_T		offset,
				u_char		*buffer,
				size_t		rsize,
				ssize_t		tsize);

/* dtusage.c */
extern char *version_str;
extern void dthelp(void), dtusage(void), dtversion(void);

/* dtprocs.c */
extern void abort_procs(void);
extern void await_procs(void);
extern pid_t fork_process(void);
extern pid_t start_procs(void);
extern pid_t start_slices(void);
extern void init_slice(struct dinfo *dip, int slice);
extern char *make_unique_file(char *file);
extern void make_unique_log(void);
extern char *FmtLogFile(char *logfile);

#if !defined(_QNX_SOURCE)
/*
 * POSIX does *not* define a special device interface, and since no
 * Magtape API exists, these functions are operating system dependent.
 * [ I'll add QNX tape functions after I find out the interface. ]
 */

/* dttape.c */

#if defined(_QNX_SOURCE) || defined(SCO)
extern int DoIoctl(dinfo_t *dip, int cmd, int argp, caddr_t msgp);
#else /* !defined(_QNX_SOURCE) && !defined(SCO) */
extern int DoIoctl(dinfo_t *dip, int cmd, caddr_t argp, caddr_t msgp);
#endif /* defined(_QNX_SOURCE) || defined(SCO) */
extern int DoMtOp(dinfo_t *dip, short cmd, daddr_t count, caddr_t msgp);
extern int DoWriteFileMark(dinfo_t *dip, daddr_t count);
extern int DoForwardSpaceFile(dinfo_t *dip, daddr_t count);
extern int DoBackwardSpaceFile(dinfo_t *dip, daddr_t count);
extern int DoForwardSpaceRecord(dinfo_t *dip, daddr_t count);
extern int DoBackwardSpaceRecord(dinfo_t *dip, daddr_t count);
extern int DoRewindTape(dinfo_t *dip);
extern int DoTapeOffline(dinfo_t *dip);
extern int DoRetensionTape(dinfo_t *dip);

#if defined(__osf__)			/* Really DEC specific. */

extern int DoSpaceEndOfData(dinfo_t *dip);
extern int DoEraseTape(dinfo_t *dip);
extern int DoTapeOnline(dinfo_t *dip);
extern int DoLoadTape(dinfo_t *dip);
extern int DoUnloadTape(dinfo_t *dip);

#endif /* defined(__osf__) */

#else /* defined(_QNX_SOURCE) */

extern int DoWriteFileMark(dinfo_t *dip, daddr_t count);

#endif /* !defined(_QNX_SOURCE) */

/* dtaio.c */

#if defined(AIO)

#if defined(WIN32)
/*
 * We are defining aiocb structure similer to POSIX
 * aiocb structure, to emulate AIO via overlapped I/O.
 */
struct aiocb {					/* aiocb structure for windows */
	OVERLAPPED	overlap;		/* Overlapped structure */
	char		*aio_buf;		/* buffer pointer */
	HANDLE		aio_fildes;		/* file descriptro */
	OFF_T		aio_offset;		/* file offset */
	size_t		aio_nbytes;		/* Length of transfer */
	u_int32		bytes_rw;		/* bytes read/write at time of checking status by GetOverlappedResult */
	DWORD		last_error;		/* The GetLastError() value */
};
#else /* !defined(WIN32) */
#  if defined(AIX52)
/*
 * NOTE: Latest SP broke AIO compiles, can't figure out why yet, so hack!
 *	The following structure stolen from sys/signal.h
 */
/*
 * sigevent structure, referred to (but not used) in asynchronous i/o.
 *
 * WARNING: The unix98 sigevent is available to user programs, but this
 *          does not itself guarantee that the kernel supports unix98 aio.
 *
 */
struct sigevent {
        union sigval            sigev_value;
        int                     sigev_signo;
        int                     sigev_notify;
#ifdef __64BIT_KERNEL
        __ptr32                 sigev_notify_function;
        __ptr32                 sigev_notify_attributes;
#else
        void                    (*sigev_notify_function)(union sigval);
        pthread_attr_t *        sigev_notify_attributes;
#endif
};
#  endif /* defined(AIX52) */
#  include <aio.h>
#endif /* defined(WIN32) */

extern struct aiocb *current_acb;

extern int dtaio_close_file(struct dinfo *dip);
extern int dtaio_initialize(struct dinfo *dip);
extern int dtaio_cancel(struct dinfo *dip);
extern int dtaio_cancel_reads(struct dinfo *dip);
extern int dtaio_read_data(struct dinfo *dip);
extern int dtaio_write_data(struct dinfo *dip);

#endif /* defined(AIO) */

/* dtmmap.c */

#if defined(MMAP)

extern int mmap_file(struct dinfo *dip);
extern int mmap_flush(struct dinfo *dip);
extern int mmap_reopen_file(struct dinfo *dip, int mode);
extern int mmap_validate_opts(struct dinfo *dip);
extern int mmap_read_data(struct dinfo *dip);
extern int mmap_write_data(struct dinfo *dip);

#endif /* defined(MMAP) */

#if defined(FIFO)

extern int fifo_open(struct dinfo *dip, int mode);

#endif /* defined(FIFO) */

/* dteei.c */

#if defined(EEI)

#include <sys/mtio.h>

extern long mt_blkno, mt_fileno;

/*
 * Functions for Processing EEI Data:
 */
extern bool HandleTapeResets(struct dinfo *dip);

extern bool check_eei_status(struct dinfo *dip, bool retry);
extern void clear_eei_status(int fd, bool startup);
extern int get_eei_status(int fd, struct mtget *mt);

extern void print_mtstatus(int fd, struct mtget *mt, bool print_all);
extern void print_mtio(int fd, struct mtget *mt);
extern void print_eei_status(u_int eei_status);
extern void print_cam_status(u_int cam_status);
extern void print_scsi_status(u_char scsi_status);
extern void print_sense_data(u_char *scsi_sense_ptr);

#endif /* defined(EEI) */
